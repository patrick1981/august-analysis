# August Leave Request — Plain-English Packet

When an employee makes a timely request for leave, the supervisor must either approve the request and schedule the leave at the time requested by the employee or, if that is not possible because of project related deadlines or the agency's workload, must schedule it at some other time.
If the employee forfeits annual leave because the supervisor did not schedule the leave or request a determination that a public exigency exists that would prevent the employee from using the leave, the supervisor's negligence constitutes administrative error and the employee's leave must be restored.
